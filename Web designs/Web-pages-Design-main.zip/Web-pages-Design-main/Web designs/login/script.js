document.getElementById("x").onclick = function(){
    if(document.getElementById("username","password").value !== ""){
        window.alert("Login SuccessFully")
    }
    else{
        window.alert("Invalid")
    }

}
